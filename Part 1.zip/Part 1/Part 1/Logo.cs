﻿using System;


namespace Part_1
{
    internal class Logo
    {

        public static void Show()
        {
            // The title color is yellow
            Console.ForegroundColor = ConsoleColor.Yellow;

            Console.WriteLine("************************************");
            Console.WriteLine("       Cybersecurity Awareness    ");
            Console.WriteLine("************************************\n");

            // Robot color (pink ,another word for it magenta)
            Console.ForegroundColor = ConsoleColor.Magenta;

            Console.WriteLine(@"
           [^_^]
          /|   |\
           |___|
          /|   |\
         /_|___|_\

        Hello! I'm your Security Bot. PLEASE stay safe always sweet chicks!!!");

            Console.ResetColor();
        }
    }


    }

