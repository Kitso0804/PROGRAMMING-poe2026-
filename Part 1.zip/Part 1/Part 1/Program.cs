﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_1
{

   public class Program
    {
        static void Main(string[] args)
        {
           //calls the Logo class
            Logo.Show();

            //voiceGreeting
            Console.WriteLine("Program starting...");

            voiceGreeting greeting = new voiceGreeting();
            greeting.PlayGreeting();

            Console.WriteLine("Greeting finished.");
            Console.WriteLine("Press ENTER");
            Console.ReadKey();

            //calls the greeting class
            string Name = Greeting.GetName(); // Ask for user's name

            
            // Press X to continue
            Console.WriteLine("\nPress X to continue...");
            ConsoleKey key;
            do
            {
                key = Console.ReadKey(true).Key;
            } while (key != ConsoleKey.X);

            Console.Clear();
            Console.WriteLine("Chatbot is now running...\n");


            //the chatting class is called
            Console.Write("Enter your name: ");
            string name = Console.ReadLine();

            Chating.Start(name);


        }
    }
}
