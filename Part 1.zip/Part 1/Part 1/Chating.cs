﻿using System;
using System.Threading;

public class Chating
{
    // Typing effect
    private static void Text(string text, int speed = 30)
    {
        foreach (char c in text)
        {
            Console.Write(c);
            Thread.Sleep(speed);
        }
        Console.WriteLine();
    }

    // Divider
    private static void Divider()
    {
        Console.ForegroundColor = ConsoleColor.Blue;
        Console.WriteLine("══════════════════════════════════════════════════");
        Console.ResetColor();
    }

    // Bot thinking animation
    private static void Thinking()
    {
        Console.ForegroundColor = ConsoleColor.Blue;
        Console.Write("Bot is thinking");
        for (int i = 0; i < 3; i++)
        {
            Thread.Sleep(400);
            Console.Write(".");
        }
        Console.WriteLine();
        Console.ResetColor();
    }

    // Bot message
    private static void BotMessage(string message, ConsoleColor color = ConsoleColor.Green)
    {
        Console.ForegroundColor = color;
        Console.Write("ChatBot: ");
        Text(message);
        Console.ResetColor();
    }

    // User input
    private static string UserMessage(string name)
    {
        Console.ForegroundColor = ConsoleColor.DarkYellow;
        Console.Write($"{name}: ");
        Console.ResetColor();

        string input = Console.ReadLine();

        if (string.IsNullOrWhiteSpace(input))
            return "";

        return input.ToLower();
    }

    public static void Start(string name)
    {
        Console.Clear();

        // Header
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("╔════════════════════════════════════════════════╗");
        Console.WriteLine("║           CYBERSECURITY ASSISTANT             ║");
        Console.WriteLine("╚════════════════════════════════════════════════╝");
        Console.ResetColor();
        Console.WriteLine();

        BotMessage($"Hello {name}! You can now ask me anything about cybersecurity.");
        Divider();
        BotMessage("Type 'exit' anytime to quit.");
        BotMessage("Type 'help' to see examples of questions.");
        Divider();

        while (true)
        {
            string userInput = UserMessage(name);

            if (userInput == "exit")
            {
                BotMessage("Goodbye!");
                break;
            }

            if (userInput == "help")
            {
                BotMessage("You can ask about:");
                Text("- what is my purpose");
                Text("- password safety");
                Text("- what is phishing");
                Text("- safe browsing tips");
                Text("- VPN, ransomware, GDPR, or ethical hacking");
                Divider();
                continue;
            }

            Thinking();
            Respond(userInput, name);
            Divider();
        }
    }

    private static void Respond(string input, string name)
    {
        input = input.Replace("?", "").Replace(".", "").Trim();

        string[] tempWords = input.Split(' ');
        string[] words = Array.FindAll(tempWords, w => !string.IsNullOrWhiteSpace(w));

        foreach (string word in words)
        {
            switch (word)
            {
                case "password":
                    BotMessage("Always use strong, unique passwords for each account. Consider using a password manager!");
                    return;

                case "malware":
                case "virus":
                case "trojan":
                    BotMessage("Malware is software designed to harm your computer, steal data, or gain unauthorized access.");
                    return;

                case "vpn":
                    BotMessage("A VPN encrypts your internet connection, keeping your online activity private and secure.");
                    return;

                case "encryption":
                    BotMessage("Encryption scrambles your data so only authorized parties can read it.");
                    return;

                case "ransomware":
                    BotMessage("Ransomware locks your files and demands payment. Always back up your data.");
                    return;

                case "phishing":
                    BotMessage("Phishing is when attackers trick you into giving personal info.");
                    return;
            }
        }

        if (input.Contains("purpose"))
            BotMessage("My purpose is to help you learn how to stay safe online and understand cybersecurity.");

        else if (input.Contains("how are you"))
            BotMessage("I'm good, thank you for asking!");

        else if (input.Contains("what is safe browsing") || input.Contains("browsing"))
            BotMessage("Use HTTPS websites, avoid suspicious links, and keep your browser updated.");

        else if (input.Contains("cybersecurity"))
            BotMessage("Cybersecurity is about protecting systems, networks, and data from cyber attacks.");

        else if (input.Contains(" importance of cybersecurity"))
            BotMessage("Cybersecurity is essential for protecting sensitive data, ensuring operational continuity, and safeguarding individuals and organizations from increasingly sophisticated cyber threats.");

        else if (input.Contains(" cybersecurity policy"))
            BotMessage("A cyber security policy is a set of guidelines and procedures for protecting an organization’s information systems and data from cyber threats. ");
       
        else if (input.Contains("two-factor") || input.Contains("2fa"))
            BotMessage("Two-factor authentication adds an extra security layer when logging in.");

        else if (input.Contains(" what is social engineering"))
            BotMessage("Social engineering manipulates people into revealing confidential information.");

        else if (input.Contains("what is ethical hacker"))
            BotMessage("An ethical hacker legally tests systems to find vulnerabilities.");

        else
            BotMessage("I'm not sure about that. Try asking something related to cybersecurity.");
    }
}