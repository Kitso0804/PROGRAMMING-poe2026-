﻿using System;
using System.Media;


public class voiceGreeting
{
    public void PlayGreeting()
    {
       //the path the wav audio is at
        string filePath = @"C:\\Users\\Student\\Desktop\\Programming 2A\\POE part1\\Part 1\\Part 1\\Properties\\voiceGreeting.wav"; 

        // this print the file path to the console
        Console.WriteLine("Looking for file at: " + filePath); 

        try
        {
            SoundPlayer player = new SoundPlayer(filePath);
            player.Load();
            // this will wait until sound finishes
            player.PlaySync(); 
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error playing sound: " + ex.Message);
        }
    }
}