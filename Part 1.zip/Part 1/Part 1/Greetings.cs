﻿using System;
using System.Threading;

public class Greeting
{
    public static string GetName()
    {
        Console.WriteLine("Hello there! Let's get to know each other better.");
        Console.Write("Please enter your name : ");
        string input = Console.ReadLine();

        // Split input by spaces
        string[] words = input.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        string Name;

        // Detect "My name is ..." format
        if (words.Length >= 3 &&
            words[0].ToLower() == "my" &&
            words[1].ToLower() == "name" &&
            words[2].ToLower() == "is")
        {
            Name = words[words.Length - 1];
        }
        else
        {
            Name = words[0]; // Otherwise, first word
        }

        // Clear screen and show welcome banner
        Console.Clear();
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("****************************************");
        Console.WriteLine($"        Welcome, {Name}, to your");
        Console.WriteLine("     Cybersecurity Awareness        ");
        Console.WriteLine("****************************************\n");
        Console.ResetColor();

        // Optional small delay
        Thread.Sleep(400);

        // Improved ASCII robot
        Console.ForegroundColor = ConsoleColor.Magenta;
        Console.WriteLine("        ┌───────────┐");
        Console.WriteLine("        │   ^   ^   │"); 
        Console.WriteLine("        │    ▽      │");  
        Console.WriteLine("        │  \\___/    |");  
        Console.WriteLine("        └───────────┘");
        Console.WriteLine("         /│     │\\");
        Console.WriteLine("        / │     │ \\");
        Console.WriteLine("          │     │");
        Console.WriteLine("         /       \\");
        Console.WriteLine("     Your Cybersecurity ChatBot\n");
        Console.ResetColor();

        // Greeting messages with typing effect
        Console.ForegroundColor = ConsoleColor.Green;
        TypeText($"Hello {Name}!", 40);
        TypeText("I'm here to assist you so you can learn how to always stay safe online.", 40);
        TypeText("Let us START!\n", 40);
        Console.ResetColor();

        return Name;
    }

    // Typing effect helper
    private static void TypeText(string text, int speed = 30)
    {
        foreach (char c in text)
        {
            Console.Write(c);
            Thread.Sleep(speed);
        }
        Console.WriteLine();
    }
}