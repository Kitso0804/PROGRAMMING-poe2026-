﻿using Part2;
using System;
using System.Threading;

public class Greetings
{
    private MainWindow _window;

    // Static ASCII Art
    private string ASCIIArt = @"
   ╔══════════════════════════════╗
   ║  ██████╗██╗   ██╗██████╗     ║
   ║ ██╔════╝╚██╗ ██╔╝██╔══██╗    ║
   ║ ██║      ╚████╔╝ ██████╔╝    ║
   ║ ██║       ╚██╔╝  ██╔══██╗    ║
   ║ ╚██████╗   ██║   ██████╔╝    ║
   ║  ╚═════╝   ╚═╝   ╚═════╝     ║
   ║                              ║
   ║   CYBERSECURITY  CHATBOT     ║
   ╚══════════════════════════════╝
   ****** STAY ALERT. STAY SAFE. ******
";

    public Greetings(MainWindow window)
    {
        _window = window;
    }

    public void ShowWelcome(string name)
    {
        // Welcome Banner
        _window.lstGreeting.Items.Add("****************************************");
        _window.lstGreeting.Items.Add($"        Welcome, {name}, to your");
        _window.lstGreeting.Items.Add("     Cybersecurity Awareness Chatbot");
        _window.lstGreeting.Items.Add("****************************************");
        _window.lstGreeting.Items.Add("");

        // Typing Effect
        TypeText($"Hello {name}!", 40);
        

        // ASCII Art
        _window.lstGreeting.Items.Add(ASCIIArt);

        // Final Messages
        _window.lstGreeting.Items.Add("");
        _window.lstGreeting.Items.Add("The System Is Ready Now, You Can Ask Anything Related To Cybersecurity.");
       
    }

    private void TypeText(string text, int delay)
    {
        string currentText = "";

        _window.lstGreeting.Items.Add("");

        int index = _window.lstGreeting.Items.Count - 1;

        foreach (char c in text)
        {
            currentText += c;

            _window.Dispatcher.Invoke(() =>
            {
                _window.lstGreeting.Items[index] = currentText;
            });

            Thread.Sleep(delay);
        }
    }
}
