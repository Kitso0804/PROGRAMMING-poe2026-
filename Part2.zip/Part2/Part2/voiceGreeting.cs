﻿using System;
using System.Media;
using System.Windows;

namespace Part2
{
    internal class voiceGreeting
    {
        public void PlayGreeting()
        {
            // WAV FILE PATH
            string filePath = @"C:\Users\Student\Desktop\Programming 2A\POE part1\Part2\Part2\voiceGreeting.wav";

            try
            {
                SoundPlayer player = new SoundPlayer(filePath);

                player.Load();

                // plays immediately in background
                player.Play();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error playing sound: " + ex.Message);
            }
        }
    }
}
