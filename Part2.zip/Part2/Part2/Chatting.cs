﻿using Part2;
using System;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

public class Chatting
{
    private MainWindow _window;

   
    // MEMORY STORAGE
    
    private string lastTopic = "";
    private string lastUserMessage = "";
    private string rememberedName = "";
    private string favouriteTopic = "";

    
    // RANDOM RESPONSES 
    
    private static readonly Random rng = new Random();

    private string[] phishingTips = new string[]
    {
        "Be cautious of emails asking for personal information. Scammers often disguise themselves as trusted organisations.",
        "Always check the sender's email address carefully, phishing emails often use slight misspellings.",
        "Never click suspicious links in emails. When in doubt, go directly to the website by typing the URL.",
        "Legitimate companies will never ask for your password via email.",
        "Look out for urgent language like 'Your account will be closed!' — this is a classic phishing tactic."
    };

    private string[] passwordTips = new string[]
    {
        "Make sure to use strong, unique passwords for each account. Avoid using personal details in your passwords.",
        "Strong passwords should be at least 12 characters long and include symbols, numbers, and letters.",
        "Consider using a passphrase , a string of random words , as it's both strong and easier to remember.",
        "Never reuse passwords across different websites. A breach on one site can expose all your accounts.",
        "Use a trusted password manager to generate and store complex passwords securely."
    };

    private string[] privacyTips = new string[]
    {
        "Review the privacy settings on your social media accounts regularly.",
        "Be careful about what personal information you share online , less is more.",
        "Use private browsing or a VPN when you want extra anonymity online.",
        "Read privacy policies before signing up to new services to understand how your data is used."
    };

    private string[] scamTips = new string[]
    {
        "If an offer sounds too good to be true, it probably is a scam.",
        "Never send money or gift cards to someone you've only met online.",
        "Be wary of unsolicited phone calls claiming to be from your bank or the government.",
        "Verify any suspicious requests by contacting the organisation directly through official channels."
    };

    private string[] vpnTips = new string[]
    {
        "A VPN encrypts your connection and hides your online activity from prying eyes.",
        "VPNs are especially useful on public Wi-Fi networks where your data could be intercepted.",
        "Using a reputable VPN can help protect your privacy and bypass geographic restrictions.",
        "Not all VPNs are equal , choose one with a no-logs policy for the best privacy."
    };

    private string[] malwareTips = new string[]
    {
        "Malware is harmful software designed to damage or steal data. Keep your antivirus updated.",
        "Avoid downloading software from untrusted sources , it may contain hidden malware.",
        "Regularly scan your device with antivirus software to detect and remove threats.",
        "Ransomware is a type of malware that locks your files. Regular backups are your best defence."
    };

    
    // CONSTRUCTOR
    
    public Chatting(MainWindow window)
    {
        _window = window;
    }

    
    // BOT OUTPUT
    
    private void BotMessage(string message)
    {
        TextBlock botText = new TextBlock();
        botText.Text = "Cyber Bot: " + message;
        botText.Foreground = Brushes.HotPink;
        

        _window.lstChat.Items.Add(botText);

        Scroll();


    }

    private void Scroll()
    {
        _window.Dispatcher.Invoke(() =>
        {
            _window.lstChat.ScrollIntoView(_window.lstChat.Items[_window.lstChat.Items.Count - 1]);
        });
    }

  
    // RANDOM PICK HELPER
    
    private string PickRandom(string[] options)
    {
        return options[rng.Next(options.Length)];
    }

    
    // MAIN RESPONSE ENGINE
   
    public void Respond(string input, string name)
    {
        input = input.ToLower().Trim();
        lastUserMessage = input;

        // Store user name from MainWindow if not yet saved
        if (string.IsNullOrEmpty(rememberedName) && !string.IsNullOrEmpty(name))
        {
            rememberedName = name;
        }

       
        // FEATURE 5: SENTIMENT DETECTION
       
        if (input.Contains("worried") || input.Contains("scared") || input.Contains("anxious"))
        {
            BotMessage("It's completely understandable to feel that way. Cybersecurity threats can be overwhelming, but I'm here to help.");
            BotMessage(PickRandom(scamTips)); // Share a helpful tip automatically
            return;
        }

        if (input.Contains("frustrated") || input.Contains("confused") || input.Contains("don't understand"))
        {
            BotMessage("Don't worry — cybersecurity can be tricky at first! Let me try to make it clearer for you.");
            HandleFollowUp();
            return;
        }

        if (input.Contains("curious") || input.Contains("interested") || input.Contains("want to learn"))
        {
            BotMessage("That's a great mindset! Curiosity is the first step to staying secure online.");

            // Remember their favourite topic if they mention one
            if (input.Contains("privacy")) favouriteTopic = "privacy";
            else if (input.Contains("password")) favouriteTopic = "password";
            else if (input.Contains("phishing")) favouriteTopic = "phishing";
            else if (input.Contains("vpn")) favouriteTopic = "vpn";
            else if (input.Contains("malware") || input.Contains("virus")) favouriteTopic = "malware";
            else if (input.Contains("scam")) favouriteTopic = "scam";

            if (!string.IsNullOrEmpty(favouriteTopic))
                BotMessage($"I remember that you're interested in {favouriteTopic}. It's a crucial part of staying safe online.");

            return;
        }

      
        //  CONVERSATION FLOW — Follow-up triggers
       
        if (input.Contains("tell me more") || input.Contains("explain more") ||
            input.Contains("what about it") || input.Contains("give me another tip") ||
            input.Contains("more information please") || input.Contains("why"))
        {
            HandleFollowUp();
            return;
        }

        
        // MEMORY — Recall user name or favourite topic
        
        if (input.Contains("remember me") || input.Contains("do you know me") || input.Contains("who am i"))
        {
            if (!string.IsNullOrEmpty(rememberedName))
                BotMessage($"Of course! Your name is {rememberedName}.");
            if (!string.IsNullOrEmpty(favouriteTopic))
                BotMessage($"You previously told me you're interested in {favouriteTopic}. Would you like more tips on that?");
            if (string.IsNullOrEmpty(rememberedName) && string.IsNullOrEmpty(favouriteTopic))
                BotMessage("I don't have much information about you yet. Tell me your name or a topic you're curious about!");
            return;
        }

        
        // KEYWORD DETECTION + RANDOM RESPONSES
       
        string[] words = input.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

        foreach (string word in words)
        {
            switch (word)
            {
                case "password":
                    lastTopic = "password";
                    BotMessage(PickRandom(passwordTips));
                    return;

                case "phishing":
                    lastTopic = "phishing";
                    BotMessage(PickRandom(phishingTips));
                    return;

                case "vpn":
                    lastTopic = "vpn";
                    BotMessage(PickRandom(vpnTips));
                    return;

                case "malware":
                case "virus":
                    lastTopic = "malware";
                    BotMessage(PickRandom(malwareTips));
                    return;

                case "scam":
                case "scams":
                    lastTopic = "scam";
                    BotMessage(PickRandom(scamTips));
                    return;

                case "privacy":
                    lastTopic = "privacy";
                    BotMessage(PickRandom(privacyTips));
                    return;
            }
        }

        // Full phrase keyword checks (Feature 2 — more keywords)
        if (input.Contains("two factor") || input.Contains("2fa") || input.Contains("two-factor"))
        {
            lastTopic = "2fa";
            BotMessage("Two-factor authentication (2FA) adds an extra layer of security by requiring a second form of verification beyond your password.");
            return;
        }

        if (input.Contains("firewall"))
        {
            lastTopic = "firewall";
            BotMessage("A firewall monitors and controls incoming and outgoing network traffic based on security rules. It's a key line of defence.");
            return;
        }

        if (input.Contains("ransomware"))
        {
            lastTopic = "malware";
            BotMessage("Ransomware encrypts your files and demands payment to restore access. Regular backups are your best defence.");
            return;
        }

        if (input.Contains("social engineering"))
        {
            lastTopic = "phishing";
            BotMessage("Social engineering manipulates people into giving up confidential information. Always verify identities before sharing sensitive data.");
            return;
        }

        
        // GENERAL RESPONSES
        
        if (input.Contains("purpose"))
            BotMessage("My purpose is to help you stay safe online and understand cybersecurity.");

        else if (input.Contains("how are you"))
            BotMessage("I'm functioning well and ready to assist you" + (string.IsNullOrEmpty(rememberedName) ? "!" : $", {rememberedName}!"));

        else if (input.Contains("cybersecurity"))
            BotMessage("Cybersecurity is the protection of systems, networks, and data from cyber attacks.");

        else if (input.Contains("safe browsing"))
            BotMessage("Use HTTPS sites, avoid suspicious links, and keep your software updated.");

        else if (input.Contains("data breach"))
            BotMessage("A data breach happens when sensitive information is accessed or stolen without permission.");

        else if (input.Contains("social engineering"))
            BotMessage("Social engineering is when attackers manipulate people into revealing confidential information.");

        else if (input.Contains("update"))
            BotMessage("Keeping your software updated helps protect your device from security vulnerabilities.");

        else if (input.Contains("backup"))
            BotMessage("Regular backups help protect your files in case of data loss, malware, or ransomware attacks.");

        else if (input.Contains("ethical hacker"))
            BotMessage("An ethical hacker legally tests systems to find and fix vulnerabilities before malicious hackers can exploit them.");

        else
            BotMessage("I'm not sure about that. Try asking about passwords, phishing, VPNs, scams, privacy, or malware.");
    }

    //  CONTEXT MEMORY HANDLER
    
    private void HandleFollowUp()
    {
        switch (lastTopic)
        {
            case "password":
                BotMessage(PickRandom(passwordTips));
                break;

            case "phishing":
                BotMessage(PickRandom(phishingTips));
                break;

            case "vpn":
                BotMessage(PickRandom(vpnTips));
                break;

            case "malware":
                BotMessage(PickRandom(malwareTips));
                break;

            case "scam":
                BotMessage(PickRandom(scamTips));
                break;

            case "privacy":
                BotMessage(PickRandom(privacyTips));
                break;

            case "2fa":
                BotMessage("To set up 2FA, go to your account's security settings and link an authenticator app or phone number.");
                break;

            case "firewall":
                BotMessage("Make sure your operating system's built-in firewall is always enabled, especially on laptops used outside the home.");
                break;

            default:
                if (!string.IsNullOrEmpty(favouriteTopic))
                    BotMessage($"Since you're interested in {favouriteTopic}, here's a tip: " + GetTipForTopic(favouriteTopic));
                else
                    BotMessage("Can you clarify your question? You can ask about passwords, phishing, VPNs, scams, privacy, or malware.");
                break;
        }
    }

    // Helper to get a tip by topic name string
    private string GetTipForTopic(string topic)
    {
        switch (topic)
        {
            case "password": return PickRandom(passwordTips);
            case "phishing": return PickRandom(phishingTips);
            case "vpn": return PickRandom(vpnTips);
            case "malware": return PickRandom(malwareTips);
            case "scam": return PickRandom(scamTips);
            case "privacy": return PickRandom(privacyTips);
            default: return "Stay safe online by keeping your software updated and using strong passwords.";
        }
    }
}