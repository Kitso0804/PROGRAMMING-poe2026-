﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Xml.Linq;

namespace Part2
{
    public partial class MainWindow : Window
    {
        // Voice greeting object
        voiceGreeting voice = new voiceGreeting();

        // Greeting screen object
        Greetings greeting;

        // Chatbot object
        private Chatting chatBot;

        // Store username
        private string userName = "";

        // Random object
        Random random = new Random();

        public MainWindow()
        {
            InitializeComponent();
            chatBot = new Chatting(this);

            // Play voice greeting immediately
            voice.PlayGreeting();
        }

        // START BUTTON
        private void start_Chatbot(object sender, RoutedEventArgs e)
        {
            StartScreen.Visibility = Visibility.Collapsed;

            NameScreen.Visibility = Visibility.Visible;
        }

        // CONTINUE BUTTON AFTER NAME
        private void continue_Click(object sender, RoutedEventArgs e)
        {
            userName = txtName.Text.Trim();

            if (!string.IsNullOrEmpty(userName))
            {
                // Hide name screen
                NameScreen.Visibility = Visibility.Collapsed;

                // Show greeting screen
                GreetingScreen.Visibility = Visibility.Visible;

                // Create greeting object
                greeting = new Greetings(this);

                // Show greeting
                greeting.ShowWelcome(userName);
            }
            else
            {
                MessageBox.Show("Please enter your name.");
            }
        }

        // CONTINUE TO CHAT SCREEN
        private void continueToChat_Click(object sender, RoutedEventArgs e)
        {
            GreetingScreen.Visibility = Visibility.Collapsed;

            ChatScreen.Visibility = Visibility.Visible;

            // Welcome message in chat
            lstChat.Items.Add("Cyber Bot: Hello " + userName + "!");
            lstChat.Items.Add("Cyber Bot: Ask me anything about cybersecurity, i am ready to assist.");


        }



        // EXIT BUTTON
        private void exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        // SEND BUTTON
        private void send_Click(object sender, RoutedEventArgs e)
        {
            string userInput = txtMessage.Text.Trim();

            if (string.IsNullOrEmpty(userInput))
                return;

            // User message color
            TextBlock userText = new TextBlock();
            userText.Text = "You: " + userInput;
            userText.Foreground = Brushes.Green;
            

            lstChat.Items.Add(userText);

            txtMessage.Clear();

            // Bot response
            chatBot.Respond(userInput, userName);
        }
    }
}
